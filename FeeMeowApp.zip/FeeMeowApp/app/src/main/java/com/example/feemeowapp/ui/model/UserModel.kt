package com.example.feemeowapp.ui.model

data class UserModel(
    val username: String,
    val password: String,
    val nama_lengkap: String,
    val phoneNumber: String,
    val location: String,
    val isLogin: Boolean
)