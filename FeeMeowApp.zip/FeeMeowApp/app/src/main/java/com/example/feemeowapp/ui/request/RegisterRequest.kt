package com.example.feemeowapp.ui.request

data class RegisterRequest(
    val username: String,
    val password: String,
    val nama_lengkap: String,
    val phoneNumber: String,
    val location: String
)
