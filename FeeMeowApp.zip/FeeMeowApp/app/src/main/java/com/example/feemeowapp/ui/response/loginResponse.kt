package com.example.feemeowapp.ui.response

import com.google.gson.annotations.SerializedName

data class LoginResult(

	@field:SerializedName("nama_lengkap")
	val namaLengkap: String? = null,

	@field:SerializedName("username")
	val username: String? = null,

	@field:SerializedName("location")
	val location: String? = null,

	@field:SerializedName("phoneNumber")
	val phoneNumber: String? = null,

	@field:SerializedName("password")
	val password: String? = null
)

data class LoginResponse(

	@field:SerializedName("loginResult")
	val loginResult: LoginResult? = null,

	@field:SerializedName("error")
	val error: Boolean? = null,

	@field:SerializedName("message")
	val message: String? = null
)
