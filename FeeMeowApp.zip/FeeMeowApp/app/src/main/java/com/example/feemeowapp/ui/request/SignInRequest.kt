package com.example.feemeowapp.ui.request

data class SignInRequest(
    val username: String,
    val password: String
)
