package com.example.feemeowapp.ui.page.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.example.feemeowapp.R
import com.example.feemeowapp.ui.adapter.AdapterSlider
import com.example.feemeowapp.ui.adapter.BreedsCatAdapter
import com.example.feemeowapp.ui.model.BreedsCat

class HomeFragment : Fragment() {

    lateinit var vpSlider: ViewPager
    lateinit var rvBreeds: RecyclerView


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view: View = inflater.inflate(R.layout.fragment_home, container, false)

        vpSlider = view.findViewById(R.id.vp_sliderHome)
        rvBreeds = view.findViewById(R.id.rv_breeds)

        var arrSlider = ArrayList<Int>()
        arrSlider.add(R.drawable.gambar_vlog)
        arrSlider.add(R.drawable.img_forum)
        arrSlider.add(R.drawable.img_access)
        arrSlider.add(R.drawable.img_kualitas)
        arrSlider.add(R.drawable.image_signup)

        val adapterSlider = AdapterSlider(arrSlider, activity)
        vpSlider.adapter = adapterSlider

        val layoutManager = LinearLayoutManager(activity)
        layoutManager.orientation = LinearLayoutManager.HORIZONTAL

        rvBreeds.adapter = BreedsCatAdapter(arrBreedsCat)
        rvBreeds.layoutManager = layoutManager

        return view
    }
    val arrBreedsCat: ArrayList<BreedsCat>get(){
        val arr = ArrayList<BreedsCat>()
        val p1 = BreedsCat()
        p1.nama = "Meong 1"
        p1.deskripsi =  "kucing lucu"
        p1.gambar = R.drawable.gambar_vlog

        val p2 = BreedsCat()
        p2.nama = "Meong 2"
        p2.deskripsi =  "asal kota bandung"
        p2.gambar = R.drawable.gambar_vlog

        val p3 = BreedsCat()
        p3.nama = "Meong 3"
        p3.deskripsi =  "asal kota lampung"
        p3.gambar = R.drawable.gambar_vlog

        val p4 = BreedsCat()
        p4.nama = "Meong 4"
        p4.deskripsi =  "asal kota palembang"
        p4.gambar = R.drawable.gambar_vlog

        arr.add(p1)
        arr.add(p2)
        arr.add(p3)
        arr.add(p4)

        return arr
    }
}