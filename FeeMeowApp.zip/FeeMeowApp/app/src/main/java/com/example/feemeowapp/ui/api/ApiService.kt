package com.example.feemeowapp.ui.api

import com.example.feemeowapp.ui.request.RegisterRequest
import com.example.feemeowapp.ui.request.SignInRequest
import com.example.feemeowapp.ui.response.LoginResponse
import com.example.feemeowapp.ui.response.RegisterResponse
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface ApiService {
    //Post Login
    @POST("login")
    fun loginUser(
       @Body request: SignInRequest
    ): retrofit2.Call<LoginResponse>

    //Post Regis
    @POST("register")
    fun registerUser(
        @Body request: RegisterRequest
    ): retrofit2.Call<RegisterResponse>
}