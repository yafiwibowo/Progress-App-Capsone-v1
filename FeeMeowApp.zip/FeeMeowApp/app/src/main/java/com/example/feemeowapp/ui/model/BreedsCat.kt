package com.example.feemeowapp.ui.model

import java.io.Serializable

class BreedsCat: Serializable {
        lateinit var nama: String
        lateinit var deskripsi: String
        var gambar: Int = 0
}